<h3>
  <img src="../assets/Tools.png" width="16" height="16" />
  <span>Tools:</span>
</h3>

- [Что такое tree shaking? Для чего используется tree shaking?](https://youtu.be/DQ0BLu6rZYc?t=599)
- [Что такое stylelint? Назовите особенности stylelint?](https://youtu.be/DQ0BLu6rZYc?t=644)
- [Что такое статический анализ кода?](https://youtu.be/DQ0BLu6rZYc?t=695)
- [Что такое Git CLI?](https://youtu.be/DQ0BLu6rZYc?t=749)
