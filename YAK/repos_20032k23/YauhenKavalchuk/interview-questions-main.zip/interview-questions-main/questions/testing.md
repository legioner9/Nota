<h3>
  <img src="../assets/Testing_Library.png" width="16" height="16" />
  <span>Testing:</span>
</h3>

- [Какие бывают виды тестирования?](https://youtu.be/i96lHslBOIc?t=47)
- [Что такое Fake в unit тестировании?](https://youtu.be/i96lHslBOIc?t=126)
- [Что такое Stub в unit тестировании?](https://youtu.be/i96lHslBOIc?t=194)
- [Что такое Mock в unit тестировании?](https://youtu.be/i96lHslBOIc?t=234)
- [Разница между Mock и Stub?](https://youtu.be/i96lHslBOIc?t=299)
- [Что такое White/Black/Grey Box-тестирование?](https://youtu.be/__neFkxAO9s?t=30)
- [Что такое Quality Gates?](https://youtu.be/__neFkxAO9s?t=145)
- [Разница между TDD и BDD?](https://youtu.be/__neFkxAO9s?t=247)
