<h3>
  <img src="../assets/Redux.png" width="16" height="16" />
  <span>State management:</span>
</h3>

- [Что такое Flux?](https://youtu.be/RpcB5jnJvcI?t=792)
- [Что такое Redux? Ключевые принципы Redux?](https://youtu.be/RpcB5jnJvcI?t=886)
- [Разница между Redux и Flux?](https://youtu.be/81yRgVQ1ciM?t=819)
- [Ключевые концепции Redux?](https://youtu.be/HBSAjY-xh3k?t=408)
- [Что такое «единственный источник истины» (Single Source of Truth)?](https://youtu.be/HBSAjY-xh3k?t=517)
- [Что такое редьюсер (Reducer)?](https://youtu.be/HBSAjY-xh3k?t=573)
- [Разница между React State и Redux State?](https://youtu.be/HBSAjY-xh3k?t=638)
- [Как выглядит поток данных в Redux-приложении?](https://youtu.be/HBSAjY-xh3k?t=706)
- [Плюсы и минусы Redux?](https://youtu.be/HBSAjY-xh3k?t=767)
