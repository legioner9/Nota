const App = () => (
  <h1>Hello world!</h1>
);

export default App;
