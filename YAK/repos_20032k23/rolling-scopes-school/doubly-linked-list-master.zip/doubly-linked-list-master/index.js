const linkedList = require('./src/linked-list');

const h = new linkedList();
window.h = h;
