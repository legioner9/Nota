export default process.env.TEST_MODE === 'auth';
