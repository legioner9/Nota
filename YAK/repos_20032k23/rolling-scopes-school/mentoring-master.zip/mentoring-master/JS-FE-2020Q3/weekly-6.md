## Запись
- https://youtu.be/0a4TQ13KPqQ

## Что необходимо сделать до 15 января:
- Сабмитнуты результаты CoreJS интервью https://app.rs.school/course/mentor/interview-technical-screening?course=js-2020-q3
- Сабмитнуть оценки студентов https://app.rs.school/course/mentor/submit-review?course=js-2020-q3
     - [Игра в пятнашки](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/gem-pazzle/codejam-the-gem-puzzle.md)
     - ["RS Selectors"](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/rs-css.md) или ["English for kids"]
     - [COVID-19 Dashboard](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/covid-dashboard.md)
     - [Presentation](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/presentation.md)
     
# Доска объявлений 
### Краткий курс по стримингу для менторов
Курс будет состоять из:
   - 2-3 теоретических занятий от опытных стримеров RS School (Антон Белый, Виктор Ковалев, ???)
   - помощи в подготовке и проведении вашего тестового стрима на выбранную вами тему, фидбек менторов 
   - релиз
   
   Записаться и оставить свои пожелания можно тут: https://docs.google.com/forms/d/e/1FAIpQLSfQ_yVz6ZrAdmSK8N7Gy_EQ5y6bh1ySpdBaUyTfvD2G1wsWEg/viewform
     
### Разыскиваются желающие менторить на курсе по React 
- Старт 15 февраля
- Вопросы можно задать в Telegram для менторов по react https://t.me/joinchat/HqpGRxMvLcMcYRlMSfc4EA
- Черновик расписания https://docs.google.com/spreadsheets/d/1oM2O8DtjC0HodB3j7hcIResaWBw8P18tXkOl1ymelvE/edit#gid=1842379604
- Регистрация https://app.rs.school/registry/mentor?course=react-2021-q1

### Разыскиваются желающие менторить на курсе по Angular 
- Старт 16 февраля
- Вопросы можно задать в Telegram для менторов по angular https://t.me/joinchat/CCegSRhjeJbNieQ0hu3iWg
- Черновик расписания https://github.com/rolling-scopes-school/lectures/blob/master/Angular/angular-course.md
- Регистрация https://app.rs.school/registry/mentor?course=angular-2021q1

### Разыскиваются желающие менторить на курсе по corejs/fe на английском 
- старт в феврале
- регистрация https://app.rs.school/registry/mentor?course=js-fe-en
