### 04 - MAY - 2021
Запись - https://www.youtube.com/watch?v=oXnWpXkfYqk

### Информация для тех, кто зарегистрировался на менторинг после 27 апреля:
https://github.com/rolling-scopes-school/mentoring/blob/master/JS-FE-2021Q1/welcome.md

### Новости:
1) Продолжаем собеседовать студентов. Очередное распределение менторов прошло 4 мая. Следующее - 11 мая. 
2) Продолжаем искать менторов https://app.rs.school/registry/mentor?course=js-fe-2021q1
3) Читаем о процессе менторинга https://docs.rs.school/#/rs-school-mentor
4) Обсуждаем задание для студентов:
   * Match-match game, Выдача 11 мая - https://github.com/rolling-scopes-school/tasks/pull/325
5) На данный момент в листе ожидания ментора находится около 280 студентов. Добрать студента из листа ожидания можно тут https://app.rs.school/course/mentor/interview-students?course=js-fe-2021Q1

### Известные проблемы
1) Оценки за интервью не отображаются в [score](https://app.rs.school/course/score?course=js-fe-2021Q1). Issue https://github.com/rolling-scopes/rsschool-app/issues/723


