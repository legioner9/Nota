# Запись
https://youtu.be/A_20YD9WUFs

# Майки RS School 2020Q1
https://docs.google.com/forms/d/e/1FAIpQLSe3OpP5-ennHFTqR7ANSdtfHZ7GKfiiKBgx7B6AYRJNcGJfFA/viewform

# Заверишился RS CloneWars
Star fighter 
	⁃	https://inikon-ragneda-star-fighter.netlify.app/

FTL
	⁃	https://medium.com/@b1122345/%D0%BA%D0%BB%D0%BE%D0%BD-ftl-%D0%BD%D0%B0-phaser-3-e104b9f9f7f4
	⁃	https://ialeks94-cloneftl.netlify.app/

Prince of Persia 
	⁃	https://medium.com/@kotiknalune/prince-of-persia-on-phaser-3-e3c810943985
	⁃	https://clonewars-prince-of-persia.netlify.app/

The‌ ‌final‌ ‌station
	⁃	https://medium.com/@annarusakovich15/%D0%B8%D0%B3%D1%80%D0%B0-the-final-station-%D0%BD%D0%B0-javascript-c58d1726415e
	⁃	https://the-final-station-js.netlify.app/

GTA
	⁃	https://medium.com/@loremipsumrrr/clonewars-gta-8c1da4e202ba
	⁃	https://gta-phaser-promo.netlify.app/

Heroes 3
	⁃	https://heroes-might-and-magic.netlify.app/
  
#  Новости RSLang
- Завершился cross-check. Оценки еще не выставлены. 
- До 24 июля проходят презентаций.

# Ищем желающих менторить на курсах по React и Angular
### Следующий старт курсов по React и Angular 27 июля.
  - https://rs.school/react/ 
  - https://rs.school/angular/ 

Регистрация для менторов тут - https://app.rs.school/registry/mentor  
Можно продолжать менторить своих текущих студентов (указывается в момент подтверждения регистрации на курс после 27 июля).  
Любые вопросы можно задать в Telegram:
- React - https://t.me/joinchat/GEzYZRUpuBtLlMWcMt0IXQ Координатор Yulia Galuzo (tg: @yuliaka71)
- Angular - https://t.me/joinchat/AAAAAE41VjE7wTf0_Gymrw Координатор Aleh Serhiyenia (tg: @Pulya10c)

Очень будем рады любой помощи! 
К сожалению, отдельных менторских маек за эти курсы выдать не получиться :(

