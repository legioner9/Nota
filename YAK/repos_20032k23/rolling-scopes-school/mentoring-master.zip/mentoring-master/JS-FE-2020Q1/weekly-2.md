# RS School Mentors Weekly #2 
21 Апреля 2020

## Запись митинга 
https://www.youtube.com/watch?v=3DKeMgjtkTc

# Что уже должно быть сделано
1. Назначены еженедельные встречи со своими студентами
2. Проверен таск [Virtual Keyboard](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/codejam-virtual-keyboard.md) и [сабмитнута оценка](https://app.rs.school/course/mentor/submit-review?course=rs-2020-q1), студенты получили ваш фидбек.
3. Студенты согласовали тему своей [презентации](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/presentation.md). 

# Что необходимо сделать до 28 апреля
1. Проверить таск - [English for kids](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/rslang/english-for-kids.md).
    - Описание - https://github.com/rolling-scopes-school/tasks/blob/master/tasks/rslang/english-for-kids.md 
    - Кросс-чек проверка стартует 23 апреля
