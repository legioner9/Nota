# Запись
https://youtu.be/-eOZgkCHm1U

# Новости
### 1. JS Dev Day 2020. Приглашаем всех! 
https://community-z.com/events/jsdevday2020

### 2. Отчисление студентов. Часть 2.
Вчера были отчислены студенты, у которых все нижеперечисленные таски без оценок:
- English for Kids
- Cross-Check: English for Kids
- Cross-check: MovieSearch
- CoreJS

### 3. Добор студентов
  - Открываете https://app.rs.school/course/mentor/interview-students?course=rs-2020-q1
  - Нажимаете "Want To Interview"
  - Связываетесь со студентом сами (нотификаций они не получают). 
  - Если готовы брать студента без собеседования - сабмитаете пустую [фидбек форму](https://app.rs.school/course/mentor/interview-technical-screening?course=rs-2020-q1), в секции Resume выбирая "Yes, I do."

### 4. Presentation
6–7 июня с 14:00 до 22:00 GMT+3 все желающие студенту смогут выступить со своими презентациями по заданию Presentation в онлайн-формате, чтобы получить до 60 дополнительных баллов с коэффициентом 1. Форму записи для выступающих выложим 20 мая.

Сейчас ищем студентов, менторов и преподавателей из RS-сообщества в жюри-комитет мероприятия. Требование для участия в жюри одно: уровень английского B2+ (Upper-Intermediate и выше). Необходимые инструменты для оценивания и хорошую атмосферу предоставим. Надо будет послушать выступающих и оценить по пунктам „Extra points for speakers in Imaguru“ из задания:
https://github.com/rolling-scopes-school/tasks/blob/2018-Q3/tasks/presentation.md#extra-points-for-speakers-in-imaguru

Желающие, пишите в личку Варваре (hallovarvara в дискорде и телеграме). 

### 5. RS Clone Wars (Альтернативный финальный таск)
Командное соревнование по программированию клонов игр или частей игр среди студентов школы.
[Чуть больше деталей](https://docs.google.com/forms/d/e/1FAIpQLSdTOdcJSr_iR-jUVhXoPoiYH7U2Swzr-EkG3AJXQ0Ghu_9u7Q/viewform)

Ищу менторов, желающих взять на себя роль тимлидов команд.
Основные обязанности:
- формирование команды
- управление процессом разработки

По любым вопросам писать в tg: @varabei

# Что необходимо сделать
1. Проверить таск [Movie search](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/movie-search.md)
