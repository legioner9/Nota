# Запись
https://youtu.be/iDRs283n6tE

# Новости
### 1. JS Dev Day 2020. Приглашаем всех! 
https://community-z.com/events/jsdevday2020

### 2. Добор студентов
  - Открываете https://app.rs.school/course/mentor/interview-students?course=rs-2020-q1
  - Нажимаете "Want To Interview"
  - Связываетесь со студентом сами (нотификаций они не получают). 
  - Если готовы брать студента без собеседования - сабмитаете пустую [фидбек форму](https://app.rs.school/course/mentor/interview-technical-screening?course=rs-2020-q1), в секции Resume выбирая "Yes, I do."

### 3. Обсуждение RS Lang
https://github.com/rolling-scopes-school/docs/pull/133

### 4. RS Clone Wars (Альтернативный финальный таск)
Командное соревнование по программированию клонов игр или частей игр среди студентов школы.
[Чуть больше деталей](https://docs.google.com/forms/d/e/1FAIpQLSdTOdcJSr_iR-jUVhXoPoiYH7U2Swzr-EkG3AJXQ0Ghu_9u7Q/viewform)

Список заявленных игр:
- FTL
- STAR_WARS_TIE_Fighter (или любой космический dogfighter)
- The Final Station 
- Prince of persia 1989
- Lords of the Realm II (не подтверждено на 100%)

Ищу менторов, желающих взять на себя роль тимлидов команд.
Основные обязанности:
- формирование команды
- управление процессом разработки

По любым вопросам писать в tg: @varabei

# Что необходимо сделать менторам до 2 июня
1. Проверить таск [Movie search](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/movie-search.md)
2. Проверить таск [Presentation](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/presentation.md)
