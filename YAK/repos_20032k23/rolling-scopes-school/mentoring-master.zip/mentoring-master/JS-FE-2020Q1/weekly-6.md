## Запись митинга 
https://youtu.be/Ra9PWaCSRic

# Что уже должно быть сделано:
- Проверен таск Virtual Keyboard, сабмитнута оценка, студенты получили ваш фидбек
- Проверен таск English for kids, сабмитнута оценка, студенты получили ваш фидбек
- Проверен таск Movie search, сабмитнута оценка, студенты получили ваш фидбек
- Проверен таск Presentation, сабмитнута оценка, студенты получили ваш фидбек

# Что необходимо сделать до 9 июня
- Проверить таск [Fancy - Weather](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/fancy-weather.md).
Записи разборов:
- https://www.youtube.com/watch?v=K58fxd6E7Rw
- https://www.youtube.com/watch?v=4CTQad3ewvY

### Ищу ментора желающего помочь трем студентам в разработке клона игры FTL: Faster Than Light
Писать в tg @varabei
- **Upd.** Ментор найден

### Собираем анонимный фидбек
[Форма](https://docs.google.com/forms/d/e/1FAIpQLSfc_EpVVbuAhuHQnvdYJwxmF0DShhWXYXkn3oaN0PsJKvcy2A/viewform)

### Изменения для следующего таска English-puzzle
- дедлайн увеличен до 14 дней
- таск стал optional (коэффициент будет 0.1)
   
