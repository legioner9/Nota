const FSM = require('./src/fsm.js');

window.FSM = FSM;
