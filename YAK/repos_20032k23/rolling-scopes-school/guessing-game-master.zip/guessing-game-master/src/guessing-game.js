class GuessingGame {
    constructor() {}

    setRange(min, max) {

    }

    guess() {

    }

    lower() {

    }

    greater() {

    }
}

module.exports = GuessingGame;
