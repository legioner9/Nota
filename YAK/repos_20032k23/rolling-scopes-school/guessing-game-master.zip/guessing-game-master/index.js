const GuessingGame = require('./src/guessing-game.js');

window.game = new GuessingGame();
