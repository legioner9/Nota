module.exports = function reverse (n) {
  
}
