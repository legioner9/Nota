module.exports = function check(str, bracketsConfig) {
  // your solution
}
