export { FooterContent } from './FooterContent';
