export const BACKEND_LINK = 'https://rss-teams-dev.herokuapp.com/graphql';
export const AUTH_BACKEND_LINK = 'https://rss-teams-dev.herokuapp.com/auth/github/';
