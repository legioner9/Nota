export { TEAMS_QUERY } from './teamsQuery';
export { USERS_QUERY } from './usersQuery';
// export { USER_QUERY } from './userQuery';
export { WHOAMI_QUERY } from './whoAmIQuery';
export { COURSES_QUERY } from './coursesQuery';
