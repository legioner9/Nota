import styled from 'styled-components';

export const StyledTableBody = styled.div`
  display: flex;
  width: 100%;
  height: 100%;
`;
