export { AdminPageWrapper } from './ContentWrapper';
