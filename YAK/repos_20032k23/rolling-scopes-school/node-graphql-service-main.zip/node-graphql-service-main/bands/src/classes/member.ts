export class Member {
    constructor(
        public artist: string,
        public instrument: string,
        public years: string[],
    ) {}
}
