module.exports = function toReadable (number) {
  
}
