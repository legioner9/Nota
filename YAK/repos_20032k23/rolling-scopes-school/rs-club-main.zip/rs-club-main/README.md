# rs-club
The Rolling Scopes Club. Let's meet regularly to share ideas, answer questions, and learn together.
