---
name: Cross-Check appeal
about: issue to check work by activists
title: Cross-Check 'task-name' 'github nickname'
---

1. A link to your deployed project
    - [link](https://github.com/)
2. A link to the project repository on Github.
    - [link](https://github.com/)
3. A link to the task
    - [link](https://github.com/)
4. A Link to the checklist for evaluating the task (if it exists)
    - [link](https://github.com/)
5. A screenshot of cross-checking marks

6. A final score after self-assessment, with comments

7. A cross-check score of your Score 
