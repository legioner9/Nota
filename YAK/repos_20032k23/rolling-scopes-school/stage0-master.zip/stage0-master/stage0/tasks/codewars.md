# Codewars

В этом задании вам необходимо решить несколько задач на сайте https://www.codewars.com/

### String
  1. 8 kyu https://www.codewars.com/kata/reversed-strings
  2. 8 kyu https://www.codewars.com/kata/palindrome-strings
  3. 7 kyu https://www.codewars.com/kata/anagram-detection
### Number
  4. 8 kyu https://www.codewars.com/kata/opposite-number
  5. 8 kyu https://www.codewars.com/kata/even-or-odd
  6. 8 kyu https://www.codewars.com/kata/century-from-year
  7. 7 kyu https://www.codewars.com/kata/greatest-common-divisor
  8. 7 kyu https://www.codewars.com/kata/factorial  
### Array
  9. 8 kyu https://www.codewars.com/kata/removing-elements
  10. 8 kyu https://www.codewars.com/kata/remove-duplicates-from-list
  11. 8 kyu https://www.codewars.com/kata/sum-of-positive
  12. 7 kyu https://www.codewars.com/kata/find-the-capitals
  13. 7 kyu https://www.codewars.com/kata/fizz-buzz  
  14. 7 kyu https://www.codewars.com/kata/shortest-word
  15. 7 kyu https://www.codewars.com/kata/square-every-digit

## Как сабмитить задание
Codewars - автопроверяемый таск.  
После окончания работы над заданием зайдите в rs app https://app.rs.school/, выберите **Auto-Test**, в выпадающем списке выберите **Codewars stage 0**, нажмите кнопку **Submit**. Справа отобразится результат проверки.  

Сабмитить задание можно сколько угодно раз, каждый следующий сабмит перезаписывает предыдущий.

Ваш никнейм на сайте codewars должен быть таким же, как и GitHub никнейм, под которым вы зарегистрировались в rs app. Если указанный никнейм на codewars занят, добавьте к своему GitHub никнейму окончание -rss. Изменить никнейм на codewars можно по ссылке https://www.codewars.com/users/edit

## Критерии оценки

**Максимальный балл за задание +15, по 1 баллу за каждую решённую задачу**

## Материалы

- [Codewars. Онлайн самоучитель по программированию](https://youtu.be/Jm7nca3jk4M)
- [Решение задач с Codewars. Level 8](https://youtu.be/pPJOen-1-mw)
