# Тест по code quality: generic-principles 

Тест на платформе [app.rs.school](https://app.rs.school/) на знание и понимание [generic principles guidelines](https://rolling-scopes-school.github.io/stage0/#/stage1/tasks/clean-code/guidelines/generic-principles).
У вас 2 попытки. Всего 13 вопросов. Порог прохождения - 84% (2 ошибки).

**Внимание!** Чтобы получить максимальный балл, необходимо прочесть весь-весь документ!

**Успехов!**