# Module content

- Introduction​
- - What is typescript?
- - Why should I use typescript?
- TypeScript features
- - Base types
- - Array
- - Tuples
- - Functions
- - Enum
- - Type alias + overview of setting typescript aliases
- - Unions
- - Interface
- - Generic
- Usage in RN project
