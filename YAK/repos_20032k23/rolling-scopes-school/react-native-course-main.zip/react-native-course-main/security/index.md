# Security 

1. What is security and why do we need it?
2. Storing Sensitive Information
3. Selection of Local Storage for data persistence
4. Deep Linking
5. Authentication Methods
6. IOS Specific Security Concerns
7. Android Specific Security Concerns
8. SSL Encryption & SSL Pinning (Secure data transfer)
