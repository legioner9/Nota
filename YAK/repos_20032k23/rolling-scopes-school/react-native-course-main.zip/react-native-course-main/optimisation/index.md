# Module content

1. Intro (how does RN works, why performance issues can be faced)
2. How to measure performance of RN app
3. Common ways to improve performance (console statements; FlatList; React.memo(); useMemo()/useCallback(); images: sizes and format, caching; aminations; unnecessary dependencies; Reselect; inline anonymous functions
4. Hermes 
