# Module content

1. Testing in software development
    - testing role
    - benefits
    - testing scope
2. Testing Pyramid
3. Unit tests
    - pros and cons
4. TDD & BDD
5. Testing statistic
6. React Native testing libraries
    - overview
    - comparison
7. Jest as a testing framework
    - set up & configure
    - test structure
    - expect function
    - mocking & jest object
    - snapshots
    - coverage
8. Husky
    - overview
