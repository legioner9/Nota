# Third-party libraries

## Table of contents

1. Finding libraries
1. Determining library compatibility
1. Installing and linking libraries
   1. Android
   1. IOS
1. Adding icons
1. Adding custom fonts
1. Google Maps integration
1. Stripe integration
