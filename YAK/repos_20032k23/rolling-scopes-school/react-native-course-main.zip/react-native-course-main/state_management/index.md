# Module content

1. Introduction
2. Props Drilling
3. Context
4. Undirectional Data Flow
5. Flux
6. Redux
  - Core Concepts
  - Three Principles
  - Redux Toolkit
