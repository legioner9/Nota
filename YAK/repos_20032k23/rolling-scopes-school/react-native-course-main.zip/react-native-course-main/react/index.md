# Module content

- React foundation
- - What is it React?​
- - JSX
- - Components and props
- React lifecycle​
- React hooks and HOCs​
- - Motivation
- - Basic hooks
- - Hook rules
- - Custom hooks
- - Hoc
- Controlled/Uncontrolled components
- Reconciliation
- Fiber​
