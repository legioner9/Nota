## Streaming
Giving lectures via YouTube Live

## You will need
- A сomputer with a web camera
- Internet 3G or higher speeds
- Discord chat
  - rights to post to the #announcements channel.
- Open Broadcast Studio (OBS)
- YouTube Broadcast Rights Community Channel https://www.youtube.com/channel/UC578nebW2Mn-mNgjEArGZug
    - granting of rights can take up to 48 hours (request the rights to broadcast + 24 hours to wait)
    - how to grant rights - https://support.google.com/youtube/answer/4628007?hl=en
    - Rolling Scopes (Maxim Shastel, Dzmity Varabei), Anton Bely, Dzianis Sheka, Pavel Razuvalov, Sergey Shalyapin can grant rights
    - For broadcasting you need only the broadcast code, which can be given by the person administering the channel.
    - It is advisable to make a test run before broadcasting, use the channel https://www.youtube.com/channel/UC96625SDIZVxP-MRid1w8sQ

## Discord
Discord chat is used to announce the broadcast and communicate with the participants of the webinar:
- The announcement of the webinar must be posted in the #announcements channel, and before the start, add a link to the broadcast
- To get the rights to post to #announcements, write to any admin
- The channel # live-streaming is used to communicate with students during the broadcast

Read more about Discord's structure

## OBS Configuration
The application Open Broadcast Studio (OBS) is necessary in order to stream the image from the screen and web camera, the sound from the microphone.
Steps
1. Install Open Broadcast Studio (OBS)
2. Set the stream parameters
3. Set output stream parameters (to record locally)
4. Customize the scene - add a screen capture, add a web camera, if necessary
5. Check the video and sound parameters by starting recording locally
Full video instruction

## YouTube Broadcast Settings Configuration
Steps
1. Open the dashboard live broadcast
2. Set the delay options in stream options
3. Add the name of the stream, description and preview
• you can make a preview from, for example, such template in the figma - https://www.figma.com/file/40sDhGHQgU0DmBLuu0Qim8/youtube_thumbnails?node-id=0%3A6
4. Copy the broadcast key from the stream dashboard to OBS
Have a great streaming!
