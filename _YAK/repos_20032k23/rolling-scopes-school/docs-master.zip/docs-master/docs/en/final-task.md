## Course project

## FAQ
### Question: Who checks the course project?
Answer: Your mentor checks your project at preliminary stages. Final work  is checked by a randomly chosen mentor.

### Question: Does the course project assessment resemble the review process of a regular task?
Answer: Yes, in a dialogue format. Mentor who reviews the project leaves comments and can ask to fix something or to clarify something.

### Question: Are there any additional requirements for commits?
Answer: The final solution of the project should keep the history of commits being made during intermediate steps.

### Question: what to do if I can't get the course project done on time/ planning to overdue it for a couple days?
Answer: You should notify a mentor who has been assigned for the final task review. Algorithm is simple:
1. Create a Pull Request in any case
2. Describe in detail your situation in Pull Request text (it's preferable to include it at the beginning and to visually highlight it). Leave your contacts if it is necessary.