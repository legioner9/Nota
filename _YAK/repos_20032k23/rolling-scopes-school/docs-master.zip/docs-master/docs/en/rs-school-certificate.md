## RS School Certificate

At students’ request, we do not issue certificates on a massive scale and set a threshold for each course.

Usually the passing score equals to 55% of the best result in the course. For example, the best student scores 1884 points, 0.55 * 1884 ~ = 1000. Thus, the passing score is 1000

### Minimum requirements for obtaining a certificate

* `CoreJS Interview` score - 4+
* Total passing score – 1000

### Task retakes to receive a certificate

To obtain a certificate, you can retake/submit the missing tasks. Contact @davojta on Discord.

To obtain a certificate, students from the 2019q3 enrollment can submit the following tasks:

* Fancy - weather (first big task)
* Simple Piskel Clone (last big task)
  
Missing the deadline for these two tasks is not taken into account for obtaining a certificate.
