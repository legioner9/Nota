## Support the community

The Rolling Scopes is a non-profit community. Developers work day and night, putting their strengths and knowledge into RS for free and in their free time. We started a “piggy bank” for different RS needs. Support us here - https://www.patreon.com/therollingscopes
