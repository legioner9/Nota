## Первое домашнее задание
1. Внимательно прочитать [документацию](https://docs.rs.school/)
![Внимательно прочитать документацию](../images/manual.jpg)
2. Зарегистрироваться на [платформе школы](https://docs.rs.school/#/how-to-enroll)
3. Присоединиться к [Discord/Telegram](https://docs.rs.school/#/rs-school-chats)
4. Посмотреть запись вводного занятия - [YouTube канал школы](https://youtube.com/c/rollingscopesschool)
5. Задания, которые уже можно выполнять:
    - https://github.com/rolling-scopes-school/tasks/blob/master/tasks/stage-1/HTML-CSS-self-ru.md
    - https://github.com/rolling-scopes-school/tasks/blob/master/tasks/git-markdown.md
    - https://github.com/rolling-scopes-school/tasks/blob/master/tasks/codejam-cv.md
6. Алгоритмические задания будут выданы на второй неделе обучения.
