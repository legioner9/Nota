### Module description
This module helps you to answer the questions:
* [What is front-end?](https://www.youtube.com/watch?v=GJ8jidDdWVg&ab_channel=Codecademy)
* [What are the common requirements for a junior developer?](https://github.com/rolling-scopes-school/tasks/blob/master/stage0/modules/js-fe-developer/js-l1-position-requirements.md)
* [Is there a roadmap for front-end developers?](https://roadmap.sh/frontend)

