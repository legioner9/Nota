### Module description
This week you will learn about the popular resource - Figma. Figma - is a web-based graphics editing and user interface design app. 

### Education materials
* [Video course. Figma for Developers - Quick Tutorial](https://www.youtube.com/playlist?list=PL7e8VJ_ZN6epq-oiYOufiuPI-fpDC2Mby)