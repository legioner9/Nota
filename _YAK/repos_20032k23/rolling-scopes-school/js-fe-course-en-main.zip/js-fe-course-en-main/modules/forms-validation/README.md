### Module description
You will learn how to work with forms, its events and how you can handle them. 

### Education materials
* [Video. HTML Forms and JavaScript](https://www.youtube.com/watch?v=ikR9DsGMUMc)
* [Video. DOM API & Events (starting from the Form Events)](https://youtube.com/watch?v=pcmL9apdlMo&list=PLzLiprpVuH8e1YNSEXMtjOuB1uxqQLYED&t=2232s)
* [javascript.info. Forms, controls](https://javascript.info/forms-controls)
* [MDN. Web forms — Working with user data](https://developer.mozilla.org/en-US/docs/Learn/Forms)
* [MDN. Client-side form validation](https://developer.mozilla.org/en-US/docs/Learn/Forms/Form_validation)
