## How to pass the test?

1. Authorized in the RS app
2. Choose the Auto-Test option in the main menu
   ![Choose the Auto-Test option in the main menu](./images/auto-test-option.png)
3. Find the appropriate test in the dropdown
   ![Find the appropriate test in the dropdown](./images/choose-test.png)
4. Pay attention to the precondition. It might be different from test to test
   ![ Pay attention to the precondition](./images/test-preconditions.png)