# Core JS 101

## Task
The task is to implement functions on different Core JS topics. There are eight modules with different tasks. Each module consists of tasks for specified topic:

1. Strings
2. Numbers
3. Arrays
4. Date
5. Objects
6. Promises
7. Conditions and Loops
8. Functions and Closures

### The detailed information you find by the [link](https://github.com/mikhama/core-js-101)
