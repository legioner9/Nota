# Rolling Scopes School Uzbekistan

## Please open the [wiki](https://github.com/rolling-scopes-school/RS-Uzbekistan/wiki).
