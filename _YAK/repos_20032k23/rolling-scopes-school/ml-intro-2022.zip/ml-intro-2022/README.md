# RS School Machine Learning course
CURRENT RUN
- This is the second run 2022 version
- Materials and assignments information for each topic are in corresponding folders
