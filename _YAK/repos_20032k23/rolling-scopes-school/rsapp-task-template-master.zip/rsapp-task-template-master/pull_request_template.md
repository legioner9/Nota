# ⚠️ ALL CHECKOBOXES MUST BE CHECKED BEFORE SUBBMITING A PULL REQUEST ⚠️

- [ ] I confirm that everything below is true
- [ ] I understand that I'm not supposed to put solution to this repository
- [ ] I confirm that It is not a solution to the task, but fix in task itself
- [ ] In case if it is a solution I agree to get **-100 points** for the task 
