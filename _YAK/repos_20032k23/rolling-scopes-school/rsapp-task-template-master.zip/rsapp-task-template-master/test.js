const assert = require('assert');

it('true should be true', () => {
  assert.equal(true, true);
});
