export enum ENVIRONMENT {
  Production = 'production',
  Develop = 'develop',
}
