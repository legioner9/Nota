export interface IPagination {
  skip: number;
  take: number;
}
