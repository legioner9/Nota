export interface IEntityList<T> {
  count: number;
  results: T[];
}
