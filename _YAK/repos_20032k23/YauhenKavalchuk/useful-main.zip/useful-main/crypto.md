# Поддержать в криптовалюте!

Поддержать канал, или курс можно и в криптовалюте:

|Crypto|Number|
|--------|-----------|
|BTC|`bc1q37p53m57sqcjec78k79hth5p8waalt63cje065`|
|LTC|`ltc1qlqh6hwuuwkzwkctcqmszkn7k9wxtaayj65epg7`|
|USDT [TRC20]|`TRhMsh8z7QQPsFNFbEyirprsRBtgECHxbM`|
|BNB [Beacon Chain]|`bnb12fkey8xd8skl5u9p7mc9vvkdwr4uzjdg67j0jr`|
|QTUM|`QZt6cj7w5ca51LCfdqefZAjLnSKicWzmMP`|
|SOL|`4fg2mhhKP1MhHwD7PfuK3hzpegRzrQm6gd1zDdPw4um4`|
|DOGE|`DGtdfyV4NR95xxgTQkH8CYGDwaEg6PZfeN`|
|Baby Doge [BEP]|`0x99f485FF7fff1919Cb66b9069B09947AA26BfC45`|
|ETH|`0x99f485FF7fff1919Cb66b9069B09947AA26BfC45`|
|USDT [ERC20]|`0x99f485FF7fff1919Cb66b9069B09947AA26BfC45`|
|LUNA [ERC20]|`0x99f485FF7fff1919Cb66b9069B09947AA26BfC45`|
|USDC [ERC20]|`0x99f485FF7fff1919Cb66b9069B09947AA26BfC45`|
|BNB [Smart Chain]|`0x99f485FF7fff1919Cb66b9069B09947AA26BfC45`|
