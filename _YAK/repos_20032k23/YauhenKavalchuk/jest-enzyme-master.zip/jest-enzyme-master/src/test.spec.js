it ('should be valid', () => {
  expect(1).toBe(1);
});

it ('should return error', () => {
  expect(1).toBe(2);
});
